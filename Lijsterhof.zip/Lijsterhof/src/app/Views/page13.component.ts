import { Component, Input, ViewChild, AfterViewInit } from '@angular/core';

@Component({
    selector: 'page13',
    templateUrl: './page13.component.html',
  })

  export class Page13Component {}