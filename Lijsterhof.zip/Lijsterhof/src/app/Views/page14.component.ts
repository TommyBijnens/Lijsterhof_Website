import { Component, Input, ViewChild, AfterViewInit } from '@angular/core';

@Component({
    selector: 'page14',
    templateUrl: './page14.component.html',
  })

  export class Page14Component {}