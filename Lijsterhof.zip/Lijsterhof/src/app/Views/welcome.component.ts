import { Component, Input, ViewChild, AfterViewInit } from '@angular/core';

@Component({
    selector: 'welcome',
    templateUrl: './welcome.component.html',
  })

  export class WelcomeComponent {}